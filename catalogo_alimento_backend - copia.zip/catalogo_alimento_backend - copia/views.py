from rest_framework import viewsets
from .models import *
from .serializers import *

class AcidoGrasoViewSet(viewsets.ModelViewSet):
    queryset = AcidoGraso.objects.all()
    serializer_class = AcidoGrasoSerializer

class BeneficioViewSet(viewsets.ModelViewSet):
    queryset = Beneficio.objects.all()
    serializer_class = BeneficioSerializer

# Continúa igual para cada modelo…

# (Puedo generarte todo el resto si prefieres copiar en un solo archivo .py)
