from rest_framework import serializers
from .models import *

class AcidoGrasoSerializer(serializers.ModelSerializer):
    class Meta:
        model = AcidoGraso
        fields = '__all__'

class BeneficioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Beneficio
        fields = '__all__'

class CategoriaIngredienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoriaIngrediente
        fields = '__all__'

class CategoriaPlatilloSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoriaPlatillo
        fields = '__all__'

class CiudadSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ciudad
        fields = '__all__'

class CompuestoBioactivoSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompuestoBioactivo
        fields = '__all__'

class EstadoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Estado
        fields = '__all__'

class IngredienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ingrediente
        fields = '__all__'

class IngredienteAcidoGrasoSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredienteAcidoGraso
        fields = '__all__'

class IngredienteBeneficioSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredienteBeneficio
        fields = '__all__'

class IngredienteCompuestoSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredienteCompuesto
        fields = '__all__'

class IngredienteMacronutrienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredienteMacronutriente
        fields = '__all__'

class IngredienteMineralSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredienteMineral
        fields = '__all__'

class IngredienteSustanciaSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredienteSustancia
        fields = '__all__'

class IngredienteVitaminaSerializer(serializers.ModelSerializer):
    class Meta:
        model = IngredienteVitamina
        fields = '__all__'

class MacronutrienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Macronutriente
        fields = '__all__'

class MineralSerializer(serializers.ModelSerializer):
    class Meta:
        model = Mineral
        fields = '__all__'

class MineralesSerializer(serializers.ModelSerializer):
    class Meta:
        model = Minerales
        fields = '__all__'

class PaisSerializer(serializers.ModelSerializer):
    class Meta:
        model = Pais
        fields = '__all__'

class PlatilloSerializer(serializers.ModelSerializer):
    class Meta:
        model = Platillo
        fields = '__all__'

class PlatilloIngredienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = PlatilloIngrediente
        fields = '__all__'

class SustanciaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Sustancia
        fields = '__all__'

class VitaminaSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vitamina
        fields = '__all__'

class VitaminasSerializer(serializers.ModelSerializer):
    class Meta:
        model = Vitaminas
        fields = '__all__'
