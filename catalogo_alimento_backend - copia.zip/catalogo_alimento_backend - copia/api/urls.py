from django.urls import path
from rest_framework.response import Response
from rest_framework.decorators import api_view

@api_view(['GET'])
def hello(request):
    return Response({"mensaje": "API funcionando correctamente"})

urlpatterns = [
    path('', hello),
]
